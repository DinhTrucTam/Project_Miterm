/*
 * fsm_run.c
 *
 *  Created on: Nov 5, 2022
 *      Author: HP
 */
#include "fsm_run.h"
#include "ports_and_ pins.h"
#include "seven_segment.h"
#include "input_reading_button.h"
#include "software_timer.h"

int current_button_index = RESET_MODE;

int counter_value = 0;
int countdown_flag;

void resetSegment(void)
{
	display7SEG(ledBuffer, RESET_MODE);
}
void resetCounterCountdown(void)
{
	countdown_flag = 0;
	counter_countdown = NO_EVENT_10_SECOND;
}
void activateCounterCountdown(void)
{
	countdown_flag = 1;
}

void fsm_simple_buttons_run(void){
	// if any button is pressed, update the segment
	if (isButtonPressed() == 1)
	{
		// reset countdown to 10 seconds
		resetCounterCountdown();
		switch(current_button_index)
		{
		case RESET_MODE:
			//TODO
			counter_value = RESET_MODE;
			display7SEG(ledBuffer, counter_value);
			break;
		case INCREASE_MODE:
			//TODO
			counter_value++;
			if (counter_value == 10)
			{
				counter_value = 0;
			}
			display7SEG(ledBuffer, counter_value);
			break;
		case DECREASE_MODE:
			//TODO
			counter_value--;
			if (counter_value == -1)
			{
				counter_value = 9;
			}
			display7SEG(ledBuffer, counter_value);
			break;
		default:
			break;
		}
	}
	else
	{
		activateCounterCountdown();
	}
}
