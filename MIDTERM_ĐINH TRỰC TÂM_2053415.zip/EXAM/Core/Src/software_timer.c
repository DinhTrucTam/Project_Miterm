/*
 * software_timer.c
 *
 *  Created on: Nov 4, 2022
 *      Author: HP
 */

#include "software_timer.h"
#include "seven_segment.h"
#include "led_debugging.h"
#include "fsm_run.h"
#include "input_reading_button.h"

static int counter			 	= DEFAULT_TIMER_INTERRUPT;
	   int counter_countdown 	= NO_EVENT_10_SECOND;
	   int timer_flag 		 	= 0;
	   int timer_flag_countdown = 0;

void setTime(int num)
{
	counter = num * DEFAULT_TIMER_INTERRUPT;
}
void resetCounter(void)
{
	counter = DEFAULT_TIMER_INTERRUPT;
}
void timerInterruptService(void)
{
	if(counter > 0)
	{
		counter--;
		if (counter <= 0)
		{
			resetCounter();
			blinkLED();
		}
	}
}
void timerInterruptServiceCountdown(void)
{
	// when no button is pressed, start countdown 10 second
	if (countdown_flag == 1)
	{
		if(counter_countdown > 0)
		{
			counter_countdown--;
			if (counter_countdown <= 0)
			{
				counter_countdown = 50;
				if (counter_value == 0)
				{
					countdown_flag = 0;
					counter_value = 0;
				}
				else counter_value--;
				display7SEG(ledBuffer, counter_value);
			}
		}
	}
}
