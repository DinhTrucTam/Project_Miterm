/*
 * led_debugging.c
 *
 *  Created on: Nov 5, 2022
 *      Author: HP
 */

#include "led_debugging.h"

void blinkLED(void)
{
	HAL_GPIO_TogglePin(LED_RED_PORT, LED_RED_PIN);
}
