/*
 * input_processing_button.c
 *
 *  Created on: Nov 4, 2022
 *      Author: HP
 */
#include "input_reading_button.h"
#include "ports_and_ pins.h"
#include "fsm_run.h"

#define NUMBERS_OF_BUTTONS				3
#define DURATION_FOR_AUTO_INCREASING	100
#define BUTTON_IS_PRESSED				GPIO_PIN_RESET
#define BUTTON_IS_RELEASED				GPIO_PIN_SET
#define TIMEOUT							300

static GPIO_TypeDef* buttonPorts[NUMBERS_OF_BUTTONS] =
	{
			RESET_BUTTON_PORT,
			INC_BUTTON_PORT,
			DEC_BUTTON_PORT
	};

static uint16_t buttonPins[NUMBERS_OF_BUTTONS] =
	{
			RESET_BUTTON_PIN,
			INC_BUTTON_PIN,
			DEC_BUTTON_PIN
	};

static GPIO_PinState debounceButtonBuffer1[NUMBERS_OF_BUTTONS];
static GPIO_PinState debounceButtonBuffer2[NUMBERS_OF_BUTTONS];
static GPIO_PinState debounceButtonBuffer3[NUMBERS_OF_BUTTONS];
static GPIO_PinState debounceButtonBuffer4[NUMBERS_OF_BUTTONS];

int button_flag[NUMBERS_OF_BUTTONS];
int time_key_press = TIMEOUT;

int isButtonPressed(void)
{
	for (int index = 0; index < NUMBERS_OF_BUTTONS; index++)
	{
		if (button_flag[index] == 1)
		{
			button_flag[index] = 0;
			current_button_index = index;	// get the state to run the fsm
			return 1;
		}
	}
	return 0;
}
void buttonsReading(void)
{
	for (int i = 0; i < NUMBERS_OF_BUTTONS; i++)
	{

		// solving debouncing problems
		debounceButtonBuffer1[i] = debounceButtonBuffer2[i];
		debounceButtonBuffer2[i] = debounceButtonBuffer3[i];
		debounceButtonBuffer3[i] = HAL_GPIO_ReadPin(buttonPorts[i], buttonPins[i]);
		if ((debounceButtonBuffer1[i] == debounceButtonBuffer2[i]) &&
			(debounceButtonBuffer2[i] == debounceButtonBuffer3[i]))
		{
			if (debounceButtonBuffer4[i] != debounceButtonBuffer3[i])
			{
				debounceButtonBuffer4[i] = debounceButtonBuffer3[i];
				if (debounceButtonBuffer3[i] == BUTTON_IS_PRESSED)
				{
					button_flag[i] = 1;
					time_key_press = TIMEOUT;
				}
			}

			// case: long press (more than 3 seconds holding button)
			else
			{
				time_key_press--;
				if (time_key_press <= 0)
				{
					if (debounceButtonBuffer3[i] == BUTTON_IS_PRESSED)
					{
						button_flag[i] = 1;
					}
					time_key_press = DURATION_FOR_AUTO_INCREASING;
				}
			}
		}
	}
}
