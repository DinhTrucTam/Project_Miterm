/*
 * seven_segment.c
 *
 *  Created on: Nov 5, 2022
 *      Author: HP
 */

#include "seven_segment.h"
#include "ports_and_ pins.h"

uint8_t baseComparator 								   = 0x80;
uint8_t ledBuffer[BUFFER_SIZE] 					   	   = {0x40, 0xF9, 0x24, 0x30, 0x19, 0x12, 0x02, 0xF8, 0x00, 0x10};
					  	  	  	  	  	  //DECIMAL VALUES  0     1     2     3     4     5     6     7     8     9
GPIO_TypeDef* segmentPorts[NUMBERS_OF_LEDS_IN_SEGMENT] = {g_PORT, f_PORT, e_PORT, d_PORT, c_PORT, b_PORT, a_PORT};
uint16_t segmentPins[NUMBERS_OF_LEDS_IN_SEGMENT] 	   = {g_PIN,  f_PIN,  e_PIN,  d_PIN,  c_PIN,  b_PIN,  a_PIN};

int index_led = 0;

void display7SEG(uint8_t buffer[], int num)
{
	GPIO_PinState data_out;
	uint8_t data = buffer[num];
	data = data << 1;
	for (int i = 0; i < 7; i++)
	{
		data_out = ((data & baseComparator) == baseComparator);
		HAL_GPIO_WritePin(segmentPorts[i], segmentPins[i], data_out);
		data = data << 1;
	}
}
void update7SEG(void)
{
	display7SEG(ledBuffer, index_led);
}
