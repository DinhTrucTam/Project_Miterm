/*
 * fsm_run.h
 *
 *  Created on: Nov 5, 2022
 *      Author: HP
 */

#ifndef INC_FSM_RUN_H_
#define INC_FSM_RUN_H_

#define 	RESET_MODE		0
#define 	INCREASE_MODE	1
#define 	DECREASE_MODE	2

extern int counter_value, countdown_flag;

void fsm_simple_buttons_run(void);

#endif /* INC_FSM_RUN_H_ */
