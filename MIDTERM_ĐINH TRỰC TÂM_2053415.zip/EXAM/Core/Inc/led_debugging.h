/*
 * led_debugging.h
 *
 *  Created on: Nov 5, 2022
 *      Author: HP
 */

#ifndef INC_LED_DEBUGGING_H_
#define INC_LED_DEBUGGING_H_
#include "ports_and_ pins.h"

void blinkLED(void);

#endif /* INC_LED_DEBUGGING_H_ */
