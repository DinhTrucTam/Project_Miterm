/*
 * input_reading_button.h
 *
 *  Created on: Nov 4, 2022
 *      Author: HP
 */

#ifndef INC_INPUT_READING_BUTTON_H_
#define INC_INPUT_READING_BUTTON_H_

void buttonsReading(void);
int isButtonPressed(void);
void requirements(void);

extern int button_flag_normal[];
extern int current_button_index;

#endif /* INC_INPUT_READING_BUTTON_H_ */
