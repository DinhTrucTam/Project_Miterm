/*
 * ports_and_ pins.h
 *
 *  Created on: Nov 4, 2022
 *      Author: HP
 */

#ifndef INC_PORTS_AND__PINS_H_
#define INC_PORTS_AND__PINS_H_

#include "main.h"

// 7 segment
#define		a_PORT				a_GPIO_Port
#define		b_PORT				b_GPIO_Port
#define		c_PORT				c_GPIO_Port
#define		d_PORT				d_GPIO_Port
#define		e_PORT				e_GPIO_Port
#define		f_PORT				f_GPIO_Port
#define		g_PORT				g_GPIO_Port

#define		a_PIN				a_Pin
#define		b_PIN				b_Pin
#define		c_PIN				c_Pin
#define		d_PIN				d_Pin
#define		e_PIN				e_Pin
#define		f_PIN				f_Pin
#define		g_PIN				g_Pin

// LEDs
#define 	LED_RED_PORT		LED_RED_GPIO_Port
#define 	LED_RED_PIN			LED_RED_Pin

// Buttons
#define		RESET_BUTTON_PORT	BUTTON_RESET_GPIO_Port
#define 	INC_BUTTON_PORT		BUTTON_INC_GPIO_Port
#define 	DEC_BUTTON_PORT		BUTTON_DEC_GPIO_Port

#define		RESET_BUTTON_PIN	BUTTON_RESET_Pin
#define 	INC_BUTTON_PIN		BUTTON_INC_Pin
#define		DEC_BUTTON_PIN		BUTTON_DEC_Pin

#endif /* INC_PORTS_AND__PINS_H_ */
