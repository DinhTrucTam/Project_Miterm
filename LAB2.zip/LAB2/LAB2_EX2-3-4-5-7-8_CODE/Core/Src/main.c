/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

// LED
#define 	LED_PORT						led_GPIO_Port
#define 	LED_PIN							led_Pin
#define		DOT_PORT						two_led_GPIO_Port
#define 	DOT_PIN							two_led_Pin

// 7segments ports and pins
#define		 FIRST_SEGMENT_ENABLE_PORT		seg1_GPIO_Port
#define 	SECOND_SEGMENT_ENABLE_PORT		seg2_GPIO_Port
#define		 THIRD_SEGMENT_ENABLE_PORT		seg3_GPIO_Port
#define 	FOURTH_SEGMENT_ENABLE_PORT		seg4_GPIO_Port
#define		a_PORT							a_GPIO_Port
#define		b_PORT							b_GPIO_Port
#define		c_PORT							c_GPIO_Port
#define		d_PORT							d_GPIO_Port
#define		e_PORT							e_GPIO_Port
#define		f_PORT							f_GPIO_Port
#define		g_PORT							g_GPIO_Port

#define		 FIRST_SEGMENT_ENABLE_PIN		seg1_Pin
#define 	SECOND_SEGMENT_ENABLE_PIN		seg2_Pin
#define		 THIRD_SEGMENT_ENABLE_PIN		seg3_Pin
#define 	FOURTH_SEGMENT_ENABLE_PIN		seg4_Pin
#define		a_PIN							a_Pin
#define		b_PIN							b_Pin
#define		c_PIN							c_Pin
#define		d_PIN							d_Pin
#define		e_PIN							e_Pin
#define		f_PIN							f_Pin
#define		g_PIN							g_Pin


// Others
#define 	NUMBERS_OF_LEDS_IN_SEGMENT		7
#define 	ONE_SECOND						1000
#define		TIME							25
#define		BUFFER_1_SIZE					10
#define 	BUFFER_2_SIZE					4
#define 	START							0
#define 	END								9
#define 	ON								GPIO_PIN_RESET
#define 	OFF								GPIO_PIN_SET
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;

/* USER CODE BEGIN PV */
// exercise 2
enum status {ONE, TWO, THREE, ZERO};
enum status segment_status    						   = ONE;
int counter 		  		  						   = TIME;
int value 			  		  						   = START;
int led_counter 		  	  						   = START;
int flag											   = 0;
int count_time_segment								   = 0;
uint8_t baseComparator 								   = 0x80;
uint8_t ledBuffer1[BUFFER_1_SIZE] 					   = {0x40, 0xF9, 0x24, 0x30, 0x19, 0x12, 0x02, 0xF8, 0x00, 0x10};
					  	  	  	  	  	  //DECIMAL VALUES  0     1     2     3     4     5     6     7     8     9
GPIO_TypeDef* segmentPorts[NUMBERS_OF_LEDS_IN_SEGMENT] = {g_PORT, f_PORT, e_PORT, d_PORT, c_PORT, b_PORT, a_PORT};
uint16_t segmentPins[NUMBERS_OF_LEDS_IN_SEGMENT] 	   = {g_PIN,  f_PIN,  e_PIN,  d_PIN,  c_PIN,  b_PIN,  a_PIN};

// exercise 3
static int index_led 		  						   = 0;
uint8_t ledBuffer2[BUFFER_2_SIZE] 					   = {0x02, 0xF8, 0x00, 0x10};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */

void blinkDOT(void);
// exercise 2
void resetInitial(void);
void display7SEG(uint8_t[], int);
void sevenSegmentFromOneToNine(void);
void displaySegment(void);

// exercise 3
void setTimer(int);
void update7SEG(void);
void sevenSegmentProcessing(void);
void countInterrupt(void);
void updateClockBuffer(int, int);
void run(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void blinkSingleLED(void)
{
	HAL_GPIO_TogglePin(LED_PORT, LED_PIN);
}
void blinkDOT(void)
{
	HAL_GPIO_TogglePin(DOT_PORT, DOT_PIN);
}
void setTimer(int time)
{
	counter = time / 40;
	flag = 0;
}
//exercise 2
void resetInitial(void)
{
	HAL_GPIO_WritePin(GPIOA, FIRST_SEGMENT_ENABLE_PIN|
							 SECOND_SEGMENT_ENABLE_PIN|
							 THIRD_SEGMENT_ENABLE_PIN|
							 FOURTH_SEGMENT_ENABLE_PIN, OFF);
}
void display7SEG(uint8_t buffer[], int num)
{
	GPIO_PinState data_out;
	uint8_t data = buffer[num];
	data = data << 1;
	for (int i = 0; i < 7; i++)
	{
		data_out = ((data & baseComparator) == baseComparator);
		HAL_GPIO_WritePin(segmentPorts[i], segmentPins[i], data_out);
		data = data << 1;
	}
}
void sevenSegmentFromOneToNine(void)
{
	display7SEG(ledBuffer1, value);
	if (value == END)
	{
		value = START;
	}
	else value++;
}
void displaySegment(void)
{
	led_counter++;
	switch(segment_status)
	{
		case ONE:
			if (led_counter <= TIME)
			{
				HAL_GPIO_WritePin(FIRST_SEGMENT_ENABLE_PORT, FIRST_SEGMENT_ENABLE_PIN, ON);
				display7SEG(ledBuffer1, 1);
			}
			else
			{
				HAL_GPIO_WritePin(FIRST_SEGMENT_ENABLE_PORT, FIRST_SEGMENT_ENABLE_PIN, OFF);
				segment_status = TWO;
				led_counter = START;
			}
			break;
		case TWO:
			if (led_counter <= TIME)
			{
				HAL_GPIO_WritePin(SECOND_SEGMENT_ENABLE_PORT, SECOND_SEGMENT_ENABLE_PIN, ON);
				display7SEG(ledBuffer1, 2);
			}
			else
			{
				HAL_GPIO_WritePin(SECOND_SEGMENT_ENABLE_PORT, SECOND_SEGMENT_ENABLE_PIN, OFF);
				segment_status = THREE;
				led_counter = START;
			}
			break;
		case THREE:
			if (led_counter <= TIME)
			{
				HAL_GPIO_WritePin(THIRD_SEGMENT_ENABLE_PORT, THIRD_SEGMENT_ENABLE_PIN, ON);
				display7SEG(ledBuffer1, 3);
			}
			else
			{
				HAL_GPIO_WritePin(THIRD_SEGMENT_ENABLE_PORT, THIRD_SEGMENT_ENABLE_PIN, OFF);
				segment_status = ZERO;
				led_counter = START;
			}
			break;
		case ZERO:
			if (led_counter <= TIME)
			{
				HAL_GPIO_WritePin(FOURTH_SEGMENT_ENABLE_PORT, FOURTH_SEGMENT_ENABLE_PIN, ON);
				display7SEG(ledBuffer1, 0);
			}
			else
			{
				HAL_GPIO_WritePin(FOURTH_SEGMENT_ENABLE_PORT, FOURTH_SEGMENT_ENABLE_PIN, OFF);
				segment_status = ONE;
				led_counter = START;
			}
			break;
		default:
			break;
	}
}

// exercise 3
void update7SEG(void)
{
	switch(index_led)
	{
	case 0:
		HAL_GPIO_WritePin(FOURTH_SEGMENT_ENABLE_PORT, FOURTH_SEGMENT_ENABLE_PIN, OFF);
		HAL_GPIO_WritePin(FIRST_SEGMENT_ENABLE_PORT, FIRST_SEGMENT_ENABLE_PIN, ON);
		break;
	case 1:
		HAL_GPIO_WritePin(FIRST_SEGMENT_ENABLE_PORT, FIRST_SEGMENT_ENABLE_PIN, OFF);
		HAL_GPIO_WritePin(SECOND_SEGMENT_ENABLE_PORT, SECOND_SEGMENT_ENABLE_PIN, ON);
		break;
	case 2:
		HAL_GPIO_WritePin(SECOND_SEGMENT_ENABLE_PORT, SECOND_SEGMENT_ENABLE_PIN, OFF);
		HAL_GPIO_WritePin(THIRD_SEGMENT_ENABLE_PORT, THIRD_SEGMENT_ENABLE_PIN, ON);
		break;
	case 3:
		HAL_GPIO_WritePin(THIRD_SEGMENT_ENABLE_PORT, THIRD_SEGMENT_ENABLE_PIN, OFF);
		HAL_GPIO_WritePin(FOURTH_SEGMENT_ENABLE_PORT, FOURTH_SEGMENT_ENABLE_PIN, ON);
		break;
	default:
		break;
	}
	display7SEG(ledBuffer2, index_led);
}
void sevenSegmentProcessing(void)
{
	if (index_led == 4)
	{
		index_led = 0;
	}
	update7SEG();
	index_led++;
}
void countInterrupt(void)
{
	if (counter > START)
	{
		counter--;
		if (counter <= START)
		{
			flag = 1;
		}
	}
}
void updateClockBuffer(int hour, int minute)
{
	int div_hour = hour / 10,
	    mod_hour = hour % 10,
			div_minute = minute / 10,
			mod_minute = minute % 10;
	for (int i = 0; i < BUFFER_2_SIZE; i++)
	{
		if (i == 0)
		{
			ledBuffer2[i] = ledBuffer1[div_hour];
		}
		else if (i == 1)
		{
			ledBuffer2[i] = ledBuffer1[mod_hour];
		}
		else if (i == 2)
		{
			ledBuffer2[i] = ledBuffer1[div_minute];
		}
		else ledBuffer2[i] = ledBuffer1[mod_minute];
	}
}
void run(void)
{
	countInterrupt();
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  resetInitial();
  HAL_TIM_Base_Start_IT(&htim2);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  int hour = 19,
	  minute = 59,
	  second = 59;
  int dem = 0;

  updateClockBuffer(hour, minute);
  setTimer(ONE_SECOND);
  while (1)
  {
	  if (flag == 1)
	  {
		  updateClockBuffer(hour, minute);
		  sevenSegmentProcessing();
		  setTimer(1000);
		  dem++;
	  }
	  if (dem == 4)
	  {
	  	  second++;
	  	  if (second >= 60)
	  	  {
		  	  second = 1;
		  	  minute++;
	  	  }
	  	  if (minute >= 60)
	  	  {
		  	  minute = 0;
		  	  hour++;
	  	  }
	  	  if (hour >= 24)
	  	  {
		  	  hour = 0;
	  	  }
	  	  dem = 0;
	  	  blinkDOT();
	  	  blinkSingleLED();
	  }
    /* USER CODE END WHILE */
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 7999;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 9;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, two_led_Pin|led_Pin|seg1_Pin|seg2_Pin
                          |seg3_Pin|seg4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, a_Pin|b_Pin|c_Pin|d_Pin
                          |e_Pin|f_Pin|g_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : two_led_Pin led_Pin seg1_Pin seg2_Pin
                           seg3_Pin seg4_Pin */
  GPIO_InitStruct.Pin = two_led_Pin|led_Pin|seg1_Pin|seg2_Pin
                          |seg3_Pin|seg4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : a_Pin b_Pin c_Pin d_Pin
                           e_Pin f_Pin g_Pin */
  GPIO_InitStruct.Pin = a_Pin|b_Pin|c_Pin|d_Pin
                          |e_Pin|f_Pin|g_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	run();
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
