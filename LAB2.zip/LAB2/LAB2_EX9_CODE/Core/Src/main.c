/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
// LEDs
#define 	LED_PORT						led_GPIO_Port
#define 	LED_PIN							led_Pin
#define 	TWO_LED_PORT					two_led_GPIO_Port
#define 	TWO_LED_PIN						two_led_Pin
#define 	ON								0
#define 	OFF								1

// 7segments
#define		 FIRST_SEGMENT_ENABLE_PORT		seg1_GPIO_Port
#define 	SECOND_SEGMENT_ENABLE_PORT		seg2_GPIO_Port
#define		 THIRD_SEGMENT_ENABLE_PORT		seg3_GPIO_Port
#define 	FOURTH_SEGMENT_ENABLE_PORT		seg4_GPIO_Port
#define		a_PORT							a_GPIO_Port
#define		b_PORT							b_GPIO_Port
#define		c_PORT							c_GPIO_Port
#define		d_PORT							d_GPIO_Port
#define		e_PORT							e_GPIO_Port
#define		f_PORT							f_GPIO_Port
#define		g_PORT							g_GPIO_Port

#define		 FIRST_SEGMENT_ENABLE_PIN		seg1_Pin
#define 	SECOND_SEGMENT_ENABLE_PIN		seg2_Pin
#define		 THIRD_SEGMENT_ENABLE_PIN		seg3_Pin
#define 	FOURTH_SEGMENT_ENABLE_IN		seg4_Pin
#define		a_PIN							a_Pin
#define		b_PIN							b_Pin
#define		c_PIN							c_Pin
#define		d_PIN							d_Pin
#define		e_PIN							e_Pin
#define		f_PIN							f_Pin
#define		g_PIN							g_Pin

// 8x8 LED matrix
#define		ENABLE_0_MATRIX_PORT			enable_matrix_0_GPIO_Port
#define		ENABLE_1_MATRIX_PORT			enable_matrix_1_GPIO_Port
#define		ENABLE_2_MATRIX_PORT			enable_matrix_2_GPIO_Port
#define		ENABLE_3_MATRIX_PORT			enable_matrix_3_GPIO_Port
#define		ENABLE_4_MATRIX_PORT			enable_matrix_4_GPIO_Port
#define		ENABLE_5_MATRIX_PORT			enable_matrix_5_GPIO_Port
#define		ENABLE_6_MATRIX_PORT			enable_matrix_6_GPIO_Port
#define		ENABLE_7_MATRIX_PORT			enable_matrix_7_GPIO_Port

#define		ENABLE_0_MATRIX_PIN				enable_matrix_0_Pin
#define		ENABLE_1_MATRIX_PIN				enable_matrix_1_Pin
#define		ENABLE_2_MATRIX_PIN				enable_matrix_2_Pin
#define		ENABLE_3_MATRIX_PIN				enable_matrix_3_Pin
#define		ENABLE_4_MATRIX_PIN				enable_matrix_4_Pin
#define		ENABLE_5_MATRIX_PIN				enable_matrix_5_Pin
#define		ENABLE_6_MATRIX_PIN				enable_matrix_6_Pin
#define		ENABLE_7_MATRIX_PIN				enable_matrix_7_Pin

#define		ROW_0_MATRIX_PORT				row_matrix_0_GPIO_Port
#define		ROW_1_MATRIX_PORT				row_matrix_1_GPIO_Port
#define		ROW_2_MATRIX_PORT				row_matrix_2_GPIO_Port
#define		ROW_3_MATRIX_PORT				row_matrix_3_GPIO_Port
#define		ROW_4_MATRIX_PORT				row_matrix_4_GPIO_Port
#define		ROW_5_MATRIX_PORT				row_matrix_5_GPIO_Port
#define		ROW_6_MATRIX_PORT				row_matrix_6_GPIO_Port
#define		ROW_7_MATRIX_PORT				row_matrix_7_GPIO_Port

#define		ROW_0_MATRIX_PIN				row_matrix_0_Pin
#define		ROW_1_MATRIX_PIN				row_matrix_1_Pin
#define		ROW_2_MATRIX_PIN				row_matrix_2_Pin
#define		ROW_3_MATRIX_PIN				row_matrix_3_Pin
#define		ROW_4_MATRIX_PIN				row_matrix_4_Pin
#define		ROW_5_MATRIX_PIN				row_matrix_5_Pin
#define		ROW_6_MATRIX_PIN				row_matrix_6_Pin
#define		ROW_7_MATRIX_PIN				row_matrix_7_Pin

// Other constants
#define		TIME							1
#define		BUFFERSIZE						8
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;

/* USER CODE BEGIN PV */
GPIO_TypeDef *matrixPorts[BUFFERSIZE] 	  = {ENABLE_7_MATRIX_PORT, ENABLE_6_MATRIX_PORT,
  										 	 ENABLE_5_MATRIX_PORT, ENABLE_4_MATRIX_PORT,
  											 ENABLE_3_MATRIX_PORT, ENABLE_2_MATRIX_PORT,
  											 ENABLE_1_MATRIX_PORT, ENABLE_0_MATRIX_PORT};

uint16_t matrixPins[BUFFERSIZE] 		  = {ENABLE_7_MATRIX_PIN, ENABLE_6_MATRIX_PIN,
  								   	   	     ENABLE_5_MATRIX_PIN, ENABLE_4_MATRIX_PIN,
  											 ENABLE_3_MATRIX_PIN, ENABLE_2_MATRIX_PIN,
  											 ENABLE_1_MATRIX_PIN, ENABLE_0_MATRIX_PIN};

GPIO_TypeDef *matrixPortsRows[BUFFERSIZE] = {ROW_7_MATRIX_PORT, ROW_6_MATRIX_PORT,
  										 	 ROW_5_MATRIX_PORT, ROW_4_MATRIX_PORT,
  											 ROW_3_MATRIX_PORT, ROW_1_MATRIX_PORT,
  											 ROW_1_MATRIX_PORT, ROW_0_MATRIX_PORT};

uint16_t matrixPinsRows[BUFFERSIZE] 	  = {ROW_7_MATRIX_PIN, ROW_6_MATRIX_PIN,
  											 ROW_5_MATRIX_PIN, ROW_4_MATRIX_PIN,
  											 ROW_3_MATRIX_PIN, ROW_2_MATRIX_PIN,
  											 ROW_1_MATRIX_PIN, ROW_0_MATRIX_PIN};

uint8_t baseComparator 						   = 0x80;
uint8_t matrixBuffer_TurnOnEachLED[BUFFERSIZE] = {0xFE, 0xFD, 0xFB, 0xF7, 0xEF, 0xDF, 0xBF, 0x7F};
uint8_t matrixBuffer_AlphabetDisplay[][8] =
{
//A
		{0xFF,0xFF,0x01,0xEE,0xEE,0x01,0xFF,0xFF},
//B
		{0xE3,0xDB,0xDB,0xC3,0xDB,0xDB,0xDB,0xE3},
//C
		{0xE7,0xDB,0xFB,0xFB,0xFB,0xFB,0xDB,0xE7},
//D
		{0xE3,0xDB,0xDB,0xDB,0xDB,0xDB,0xDB,0xE3},
//E
		{0xC3,0xFB,0xFB,0xC3,0xFB,0xFB,0xFB,0xC3},
//F
		{0xC3,0xFB,0xFB,0xC3,0xFB,0xFB,0xFB,0xFB},
//G
		{0xC7,0xFB,0xFB,0xFB,0xCB,0xDB,0xDB,0xC7},
//H
		{0xDB,0xDB,0xDB,0xC3,0xDB,0xDB,0xDB,0xDB}
};

static int columnScanning = 0;
int rowScanning    = 0;
int counter		   = TIME;
static int matrixCounter  = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */
void matrixManipulatingRows(void);
void matrixManipulatingColumns(void);
void updateLEDMatrix(void);
void matrixOff(void);
void turnOnAllRows(void);
void run(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void turnOnAllRows(void)
{
	for (int i = 0; i < 8; i++)
	{
		HAL_GPIO_WritePin(matrixPortsRows[i], matrixPinsRows[i], ON);
	}
}
void updateLEDMatrix(void)
{
	if (columnScanning > 7)
	{
		columnScanning = 0;
		rowScanning++;
	}
	if (rowScanning > 7)
	{
		rowScanning = 0;
	}
	uint8_t dataForRow 	  = matrixBuffer_TurnOnEachLED[rowScanning];
	uint8_t dataForColumn = matrixBuffer_TurnOnEachLED[columnScanning];
	for (int i = 0; i < 8; i++)
	{
		HAL_GPIO_WritePin(matrixPortsRows[i], matrixPinsRows[i], ((dataForRow & baseComparator) == baseComparator));
		dataForRow = dataForRow << 1;
	}
	for (int i = 0; i < 8; i++)
	{
		HAL_GPIO_WritePin(matrixPorts[i], matrixPins[i], ((dataForColumn & baseComparator) == baseComparator));
		dataForColumn = dataForColumn << 1;
	}
	columnScanning++;
}
void updateAlphabet(void)
{
	if (columnScanning == 8)
	{
		columnScanning = 0;
		//matrixCounter++;
		matrixOff();
		if (matrixCounter == 8)
		{
			matrixCounter = 0;
		}
	}
	uint8_t dataForColumn = matrixBuffer_AlphabetDisplay[0][columnScanning];
	HAL_GPIO_WritePin(matrixPorts[7 - columnScanning], matrixPins[7 - columnScanning], ON);
	if (columnScanning != 0)
	{
		HAL_GPIO_WritePin(matrixPorts[7 - columnScanning + 1], matrixPins[7 - columnScanning + 1], OFF);
	}
	for (int j = 0; j < 8; j++)
	{
		HAL_GPIO_WritePin(matrixPortsRows[j], matrixPinsRows[j], ((dataForColumn & baseComparator) == baseComparator));
		dataForColumn = dataForColumn << 1;
	}
	columnScanning++;
}
void matrixOff(void)
{
	for (int i = 0; i < 8; i++)
	{
		HAL_GPIO_WritePin(matrixPorts[i], matrixPins[i], OFF);
	}
}
void matrixManipulatingRows(void)
{
	switch(matrixCounter)
	{
	case 0:
		HAL_GPIO_WritePin(GPIOB, row_matrix_0_Pin, ON);
		HAL_GPIO_WritePin(GPIOB, row_matrix_1_Pin|row_matrix_2_Pin|row_matrix_3_Pin|
								 row_matrix_4_Pin|row_matrix_5_Pin|row_matrix_6_Pin|
								 row_matrix_7_Pin, OFF);
		matrixCounter++;
		break;
	case 1:
		HAL_GPIO_WritePin(GPIOB, row_matrix_1_Pin, ON);
		HAL_GPIO_WritePin(GPIOB, row_matrix_0_Pin|row_matrix_2_Pin|row_matrix_3_Pin|
								 row_matrix_4_Pin|row_matrix_5_Pin|row_matrix_6_Pin|
								 row_matrix_7_Pin, OFF);
		matrixCounter++;
		break;
	case 2:
		HAL_GPIO_WritePin(GPIOB, row_matrix_2_Pin, ON);
		HAL_GPIO_WritePin(GPIOB, row_matrix_1_Pin|row_matrix_0_Pin|row_matrix_3_Pin|
								 row_matrix_4_Pin|row_matrix_5_Pin|row_matrix_6_Pin|
								 row_matrix_7_Pin, OFF);
		matrixCounter++;
		break;
	case 3:
		HAL_GPIO_WritePin(GPIOB, row_matrix_3_Pin, ON);
		HAL_GPIO_WritePin(GPIOB, row_matrix_1_Pin|row_matrix_2_Pin|row_matrix_0_Pin|
								 row_matrix_4_Pin|row_matrix_5_Pin|row_matrix_6_Pin|
								 row_matrix_7_Pin, OFF);
		matrixCounter++;
		break;
	case 4:
		HAL_GPIO_WritePin(GPIOB, row_matrix_4_Pin, ON);
		HAL_GPIO_WritePin(GPIOB, row_matrix_1_Pin|row_matrix_2_Pin|row_matrix_3_Pin|
								 row_matrix_0_Pin|row_matrix_5_Pin|row_matrix_6_Pin|
								 row_matrix_7_Pin, OFF);
		matrixCounter++;
		break;
	case 5:
		HAL_GPIO_WritePin(GPIOB, row_matrix_5_Pin, ON);
		HAL_GPIO_WritePin(GPIOB, row_matrix_1_Pin|row_matrix_2_Pin|row_matrix_3_Pin|
								 row_matrix_4_Pin|row_matrix_0_Pin|row_matrix_6_Pin|
								 row_matrix_7_Pin, OFF);
		matrixCounter++;
		break;
	case 6:
		HAL_GPIO_WritePin(GPIOB, row_matrix_6_Pin, ON);
		HAL_GPIO_WritePin(GPIOB, row_matrix_0_Pin|row_matrix_2_Pin|row_matrix_3_Pin|
								 row_matrix_4_Pin|row_matrix_5_Pin|row_matrix_0_Pin|
								 row_matrix_7_Pin, OFF);
		matrixCounter++;
		break;
	case 7:
		HAL_GPIO_WritePin(GPIOB, row_matrix_7_Pin, ON);
		HAL_GPIO_WritePin(GPIOB, row_matrix_1_Pin|row_matrix_0_Pin|row_matrix_3_Pin|
								 row_matrix_4_Pin|row_matrix_5_Pin|row_matrix_6_Pin|
								 row_matrix_0_Pin, OFF);
		matrixCounter++;
		matrixCounter = 0;
		break;
	default:
		HAL_GPIO_WritePin(GPIOB, row_matrix_0_Pin|row_matrix_1_Pin|row_matrix_2_Pin|
							     row_matrix_3_Pin|row_matrix_4_Pin|row_matrix_5_Pin|
								 row_matrix_6_Pin|row_matrix_7_Pin, OFF);
		break;
	}
}
void matrixManipulatingColumns(void)
{
	HAL_GPIO_WritePin(GPIOB, row_matrix_0_Pin|row_matrix_1_Pin|row_matrix_2_Pin|
							 row_matrix_3_Pin|row_matrix_4_Pin|row_matrix_5_Pin|
						     row_matrix_6_Pin|row_matrix_7_Pin, ON);
	switch(matrixCounter)
	{
	case 0:
		HAL_GPIO_WritePin(GPIOA, enable_matrix_0_Pin, ON);
		HAL_GPIO_WritePin(GPIOA, enable_matrix_1_Pin|enable_matrix_2_Pin|enable_matrix_3_Pin|
								 enable_matrix_4_Pin|enable_matrix_5_Pin|enable_matrix_6_Pin|
								 enable_matrix_7_Pin, OFF);
		matrixCounter++;
		break;
	case 1:
		HAL_GPIO_WritePin(GPIOA, enable_matrix_1_Pin, ON);
		HAL_GPIO_WritePin(GPIOA, enable_matrix_0_Pin|enable_matrix_2_Pin|enable_matrix_3_Pin|
								 enable_matrix_4_Pin|enable_matrix_5_Pin|enable_matrix_6_Pin|
								 enable_matrix_7_Pin, OFF);
		matrixCounter++;
		break;
	case 2:
		HAL_GPIO_WritePin(GPIOA, enable_matrix_2_Pin, ON);
		HAL_GPIO_WritePin(GPIOA, enable_matrix_1_Pin|enable_matrix_0_Pin|enable_matrix_3_Pin|
								 enable_matrix_4_Pin|enable_matrix_5_Pin|enable_matrix_6_Pin|
								 enable_matrix_7_Pin, OFF);
		matrixCounter++;
		break;
	case 3:
		HAL_GPIO_WritePin(GPIOA, enable_matrix_3_Pin, ON);
		HAL_GPIO_WritePin(GPIOA, enable_matrix_1_Pin|enable_matrix_2_Pin|enable_matrix_0_Pin|
								 enable_matrix_4_Pin|enable_matrix_5_Pin|enable_matrix_6_Pin|
								 enable_matrix_7_Pin, OFF);
		matrixCounter++;
		break;
	case 4:
		HAL_GPIO_WritePin(GPIOA, enable_matrix_4_Pin, ON);
		HAL_GPIO_WritePin(GPIOA, enable_matrix_1_Pin|enable_matrix_2_Pin|enable_matrix_3_Pin|
								 enable_matrix_0_Pin|enable_matrix_5_Pin|enable_matrix_6_Pin|
								 enable_matrix_7_Pin, OFF);
		matrixCounter++;
		break;
	case 5:
		HAL_GPIO_WritePin(GPIOA, enable_matrix_5_Pin, ON);
		HAL_GPIO_WritePin(GPIOA, enable_matrix_1_Pin|enable_matrix_2_Pin|enable_matrix_3_Pin|
								 enable_matrix_4_Pin|enable_matrix_0_Pin|enable_matrix_6_Pin|
								 enable_matrix_7_Pin, OFF);
		matrixCounter++;
		break;
	case 6:
		HAL_GPIO_WritePin(GPIOA, enable_matrix_6_Pin, ON);
		HAL_GPIO_WritePin(GPIOA, enable_matrix_0_Pin|enable_matrix_2_Pin|enable_matrix_3_Pin|
								 enable_matrix_4_Pin|enable_matrix_5_Pin|enable_matrix_0_Pin|
								 enable_matrix_7_Pin, OFF);
		matrixCounter++;
		break;
	case 7:
		HAL_GPIO_WritePin(GPIOA, enable_matrix_7_Pin, ON);
		HAL_GPIO_WritePin(GPIOA, enable_matrix_1_Pin|enable_matrix_0_Pin|enable_matrix_3_Pin|
								 enable_matrix_4_Pin|enable_matrix_5_Pin|enable_matrix_6_Pin|
								 enable_matrix_0_Pin, OFF);
		matrixCounter++;
		matrixCounter = 0;
		break;
	default:
		HAL_GPIO_WritePin(GPIOA, enable_matrix_0_Pin|enable_matrix_1_Pin|enable_matrix_2_Pin|
							     enable_matrix_3_Pin|enable_matrix_4_Pin|enable_matrix_5_Pin|
								 enable_matrix_6_Pin|enable_matrix_7_Pin, ON);
		break;
	}
}
void run(void)
{
	if (counter > 0)
	{
		counter--;
		if (counter <= 0)
		{
			counter = TIME;
			updateAlphabet();
		}
	}
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  matrixOff();
  HAL_TIM_Base_Start_IT(&htim2);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 7999;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 24;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, enable_matrix_0_Pin|enable_matrix_1_Pin|two_led_Pin|led_Pin
                          |seg1_Pin|seg2_Pin|seg3_Pin|seg4_Pin
                          |enable_matrix_2_Pin|enable_matrix_3_Pin|enable_matrix_4_Pin|enable_matrix_5_Pin
                          |enable_matrix_6_Pin|enable_matrix_7_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, a_Pin|b_Pin|c_Pin|row_matrix_2_Pin
                          |row_matrix_3_Pin|row_matrix_4_Pin|row_matrix_5_Pin|row_matrix_6_Pin
                          |row_matrix_7_Pin|d_Pin|e_Pin|f_Pin
                          |g_Pin|row_matrix_0_Pin|row_matrix_1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : enable_matrix_0_Pin enable_matrix_1_Pin two_led_Pin led_Pin
                           seg1_Pin seg2_Pin seg3_Pin seg4_Pin
                           enable_matrix_2_Pin enable_matrix_3_Pin enable_matrix_4_Pin enable_matrix_5_Pin
                           enable_matrix_6_Pin enable_matrix_7_Pin */
  GPIO_InitStruct.Pin = enable_matrix_0_Pin|enable_matrix_1_Pin|two_led_Pin|led_Pin
                          |seg1_Pin|seg2_Pin|seg3_Pin|seg4_Pin
                          |enable_matrix_2_Pin|enable_matrix_3_Pin|enable_matrix_4_Pin|enable_matrix_5_Pin
                          |enable_matrix_6_Pin|enable_matrix_7_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : a_Pin b_Pin c_Pin row_matrix_2_Pin
                           row_matrix_3_Pin row_matrix_4_Pin row_matrix_5_Pin row_matrix_6_Pin
                           row_matrix_7_Pin d_Pin e_Pin f_Pin
                           g_Pin row_matrix_0_Pin row_matrix_1_Pin */
  GPIO_InitStruct.Pin = a_Pin|b_Pin|c_Pin|row_matrix_2_Pin
                          |row_matrix_3_Pin|row_matrix_4_Pin|row_matrix_5_Pin|row_matrix_6_Pin
                          |row_matrix_7_Pin|d_Pin|e_Pin|f_Pin
                          |g_Pin|row_matrix_0_Pin|row_matrix_1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	run();
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
