/*
 * software_timer.h
 *
 *  Created on: Nov 4, 2022
 *      Author: HP
 */

#ifndef INC_SOFTWARE_TIMER_H_
#define INC_SOFTWARE_TIMER_H_

#define 	DEFAULT_TIMER_INTERRUPT		100 	// 10ms each -> 100 times will be 1 second
#define 	NO_EVENT_10_SECOND			1000	// 10ms each -> 1000 times will be 10 seconds

extern int counter_countdown;

void setTime(int num);
void setTimerFlag(void);
void resetTimerFlag(void);
void resetCounter(void);
void timerInterruptService(void);
void timerInterruptServiceCountdown(void);
extern int timer_flag;


#endif /* INC_SOFTWARE_TIMER_H_ */
