/*
 * seven_segment.h
 *
 *  Created on: Nov 5, 2022
 *      Author: HP
 */

#ifndef INC_SEVEN_SEGMENT_H_
#define INC_SEVEN_SEGMENT_H_
#include "main.h"

#define 	BUFFER_SIZE						10
#define 	NUMBERS_OF_LEDS_IN_SEGMENT		7

extern uint8_t ledBuffer[];
extern int index_led;

// functions
void update7SEG(void);
void display7SEG(uint8_t buffer[], int);

#endif /* INC_SEVEN_SEGMENT_H_ */
