/*
 * software_timer.c
 *
 *  Created on: Nov 4, 2022
 *      Author: HP
 */

#include "software_timer.h"
#include "seven_segment.h"
#include "led_debugging.h"
#include "fsm_run.h"
#include "input_reading_button.h"

static int counter			 =	DEFAULT_TIMER_INTERRUPT;
	   int counter_countdown = NO_EVENT_10_SECOND;
	   int timer_flag 	= 	0;
	   int timer_flag_countdown = 0;

void setTime(int num) 		// truyền vào giá trị thời gian giây (s)
{
	counter = num * DEFAULT_TIMER_INTERRUPT;
}
void setTimerFlag(void) 			// chuyển trạng thái của cờ (flag) để thực hiện nhiệm vụ
{
	timer_flag = 1;
}
void resetTimerFlag(void)		// đặt lại trạng thái ban đầu cho cờ
{
	timer_flag = 0;
}
void resetCounter(void)
{
	counter = DEFAULT_TIMER_INTERRUPT;
}
void timerInterruptService(void)
{
	if(counter > 0)
	{
		counter--;
		if (counter <= 0)
		{
			resetCounter(); 	// khi đếm đủ 100 lần thì reset bộ đếm để đếm lại từ 0
			blinkLED();   	// chuyển trạng thái của cờ báo hiệu thực hiện nhiệm vụ
		}
	}
}

void timerInterruptServiceCountdown(void)
{
	// when no button is pressed, start countdown 10 second
	if (countdown_flag == 1)
	{
		if(counter_countdown > 0)
		{
			counter_countdown--;
			if (counter_countdown <= 0)
			{
				counter_countdown = 50;
				if (counter_value == 0)
				{
					countdown_flag = 0;
					counter_value = 0;
				}
				else counter_value--;
				display7SEG(ledBuffer, counter_value);
			}
		}
	}
}
